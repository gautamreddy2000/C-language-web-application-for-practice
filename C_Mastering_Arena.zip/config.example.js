// Copy this file to config.js and fill in the public Supabase project values.
// These two values are safe to expose in the browser when Supabase RLS is configured correctly.
window.CMA_SUPABASE = {
  url: "https://YOUR_PROJECT.supabase.co",
  anonKey: "YOUR_SUPABASE_ANON_KEY"
};
