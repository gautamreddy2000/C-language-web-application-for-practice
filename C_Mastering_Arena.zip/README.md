# C Mastery Arena — Premium Standalone Edition

A polished, standalone C programming practice arena based on 106 questions across 11 chapters.

## What's included
- Quick Test, Full Mock, Marathon and Contest modes
- Chapter drills and Weakness Hunter
- Code Output practice
- Randomized questions
- Timers and answer navigation
- Instant answer review and explanations
- Automatic progress saving with browser `localStorage`
- No sign-in, account, Google, Gmail or LinkedIn authentication
- Responsive premium dark UI
- Footer credit: © 2026 C Mastery Arena. All rights reserved. Made with care by N.Gautam Reddy.

## Open it
For the simplest use, double-click `C_Mastering_Arena.html` and open it in a modern browser.

For reliable browser storage behavior, you can also serve the folder with any local static server and open the generated localhost URL.

## Verify
Run:

```bash
node scripts/check.mjs
```

The final HTML is standalone and no longer depends on Supabase or OAuth configuration.
