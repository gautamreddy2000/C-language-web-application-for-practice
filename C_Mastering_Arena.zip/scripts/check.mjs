import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve(new URL('..', import.meta.url).pathname);
const file=path.join(root,'C_Mastering_Arena.html');
const html=fs.readFileSync(file,'utf8');
const checks=[
 ['DOCTYPE present', /<!doctype html>/i.test(html)],
 ['106-question bank present', (html.match(/"q":/g)||[]).length===106],
 ['No sign-in/auth UI', !/sign in|authOverlay|providerLogin|supabaseClient|linkedin_oidc|Continue with Google/i.test(html)],
 ['Local progress storage present', /localStorage\.getItem\(KEY/.test(html) && /localStorage\.setItem\(KEY/.test(html)],
 ['Required footer present', /© 2026 C Mastery Arena\. All rights reserved\./.test(html) && /N\.Gautam Reddy/.test(html)],
 ['Quiz navigation present', /function next\(\)/.test(html) && /function prev\(\)/.test(html) && /function finish\(/.test(html)],
 ['Final-question guard present', /if\(S\.index<S\.questions\.length-1\)\{S\.index\+\+;renderExam\(\)\}else finish\(false\)/.test(html)],
 ['Responsive CSS present', /@media\(max-width:600px\)/.test(html)]
];
let failed=0;
for(const [name,ok] of checks){console.log(`${ok?'PASS':'FAIL'}  ${name}`);if(!ok)failed++}
if(failed)process.exit(1);
console.log(`\nVerification passed: ${checks.length}/${checks.length}`);
